import time
import math
import random
import threading
import pygame
import os

dirname = os.path.dirname(__file__)

class Baum:
    def __init__(self, x, y, nummer):
        self.x = x
        self.y = y
        self.nummer = nummer


class Cervus:
    def __init__(self, x, y, alive):
        self.x = x
        self.y = y
        self.alive = alive


class Mythread (threading.Thread):
    def __init__(self, threadid, name, running):
        threading.Thread.__init__(self)
        self.threadid = threadid
        self.name = name
        self.running = running

    def run(self):
        while self.running:
            if self.threadid == 0:
                if debug is True:
                    print("Thread 1 running.")
                main()
        print("Thread " + str(self.threadid + 1) + " shutting down.")


class Game:
    def __init__(self, waiting, counter):
        self.waiting = waiting
        self.counter = counter


width = [0, 4]
cg = [800, 1001]
posx = int(width[1] / 2)
alives = True
cervus1 = Cervus(posx, cg[0], alives)
game1 = Game(0, 0)
trees = []
movement_modifier = 1000
difficulty = 5
debug = False
debug2 = False


thread1 = Mythread(0, "main", True)

if debug is True:
    print("Debug: ")
    print("x: " + str(cervus1.x))
    print("y: " + str(cervus1.y))
    print("a: " + str(cervus1.alive))


def main():
    c = True

    def clock(c1, counter):

        ct = 0
        while c1 is True and not game1.waiting == 2:
            tr = time.time()
            t = round(tr, 2)
            if t.__eq__(ct):
                pass
            else:
                counter = hub(counter)
            ct = t
        return "Done"

    def hub(counter):
        counter = counter + 1
        speed = counter / movement_modifier

        def move_check_delete():
            if debug2 is True:
                print("----------------------------------")
                print("Cervus at x = " + str(cervus1.x) + " " + str(cervus1.alive))
            for tree in trees:
                col = False
                if tree.x == cervus1.x:
                    col = True
                if tree.y >= cg[1]:
                    trees.remove(tree)
                if not tree.y == cg[1]:
                    tree.y = tree.y + int(math.ceil(speed))
                if tree.y == cervus1.y and col is True:
                    death(counter)
                if tree.y - int(math.ceil(speed)) < cervus1.y < tree.y and col is True:
                    death(counter)
                if debug2 is True:
                    try:
                        print("Id: " + str(trees.index(tree)) + " x: " + str(tree.x) +
                              " y: " + str(tree.y) + " t: " + str(tree.nummer))
                    except ValueError:
                        print("Object deleted.")

        move_check_delete()

        def generator(maximum, counter1):
            length = len(trees)
            needed = False
            last2 = 0
            if len(trees) > 0:
                last2 = trees[-1].nummer
            if length >= maximum:
                pass
            if not length >= maximum:
                needed = True
            timer = (counter1 - last2) * int(math.ceil(speed))
            rate = (cg[1] - 1) / maximum
            ready = timer / rate
            if ready >= 1 and needed is True:
                trees.append(Baum(random.randint(0, width[1]), 1, counter1))
            if len(trees).__eq__(0):
                trees.append(Baum(random.randint(0, width[1]), 1, counter1))
            return "Done"

        generator(difficulty, counter)
        return counter

    def death(counter):
        cervus1.alive = False
        game1.counter = counter
        game1.waiting = 0
        while game1.waiting == 0:
            pass
        if game1.waiting == 1:
            main()
        if game1.waiting == 2:
            pass
        return "Done"

    clock(c, 0)
    quit()
    return


def gui():
    pygame.init()
    display_surface = pygame.display.set_mode((1001, 1001), pygame.RESIZABLE)
    pygame.display.set_caption("Cervus Run")
    color = (255, 0, 0)
    color2 = (0, 0, 0)
    bg = pygame.image.load(dirname + "\pictures\hintergrund.png")
    icon = pygame.image.load(dirname + "\pictures\icon.jpg")
    deer = pygame.image.load(dirname + "\pictures\cervus.gif")
    tree = pygame.image.load(dirname + "\pictures\cbaum.png")
    black = pygame.image.load(dirname + "\pictures\cblack.jpg")
    pygame.display.set_icon(icon)

    def start():
        starting = True
        pygame.font.get_init()
        font = pygame.font.Font('freesansbold.ttf', 32)
        text1 = font.render('Willkommen zu Cervus Run', True, color)
        text2 = font.render("Start", True, color2, color)
        textrect1 = text1.get_rect()
        textrect2 = text2.get_rect()
        textrect1.center = (501, 501)
        textrect2.center = (501, 590)
        while starting:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if textrect2.collidepoint(event.pos):
                        starting = False
            display_surface.fill(color)
            display_surface.blit(black, (0, 0))
            display_surface.blit(text1, textrect1)
            display_surface.blit(text2, textrect2)
            pygame.display.flip()
        thread1.start()
        return

    def game():
        running = True
        while running and cervus1.alive:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_a:
                        if cervus1.x > 0:
                            x = cervus1.x
                            x = x - 1
                            cervus1.x = x
                    if event.key == pygame.K_d:
                        if cervus1.x < 4:
                            x = cervus1.x
                            x = x + 1
                            cervus1.x = x
                    else:
                        pass
            deery = cervus1.y - 128
            if cervus1.x == 0:
                deerx = 0
            if cervus1.x == 1:
                deerx = 180
            if cervus1.x == 2:
                deerx = 370
            if cervus1.x == 3:
                deerx = 555
            if cervus1.x == 4:
                deerx = 745
            display_surface.fill(color)
            display_surface.blit(bg, (0, 0))
            display_surface.blit(deer, (deerx, deery))
            for treegui in trees:
                treey = treegui.y - 200
                if treegui.x == 0:
                    treex = 0
                if treegui.x == 1:
                    treex = 180
                if treegui.x == 2:
                    treex = 370
                if treegui.x == 3:
                    treex = 555
                if treegui.x == 4:
                    treex = 745
                display_surface.blit(tree, (treex, treey))
            pygame.display.flip()
        if cervus1.alive is False:
            died()
        return

    def died():
        choosing = True
        new = False
        count = game1.counter
        high_raw = open(dirname + "\pictures\h.txt", "r")
        high = int(high_raw.readline())
        high_raw.close()
        if high < count:
            new = True
            worker = open(dirname + "\pictures\h.txt", "w")
            worker.write(str(count))
            worker.close()
        font = pygame.font.Font('freesansbold.ttf', 32)
        text3 = font.render("Nochmal spielen?", True, color)
        text4 = font.render("Ja", True, color2, color)
        text5 = font.render("Nein", True, color2, color)
        text6 = font.render("Du bist gestorben. Dein Score war " + str(count) + " .", True, color)
        text7 = font.render("Das ist ein neuer Highscore! Dein alter Highscore war " + str(high) + " .", True, color)
        textrect3 = text3.get_rect()
        textrect4 = text4.get_rect()
        textrect5 = text5.get_rect()
        textrect6 = text6.get_rect()
        textrect7 = text7.get_rect()
        textrect3.center = (501, 501)
        textrect4.center = (501, 601)
        textrect5.center = (501, 701)
        textrect6.center = (501, 301)
        textrect7.center = (501, 401)
        while choosing:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if textrect4.collidepoint(event.pos):
                        choosing = False
                        cervus1.alive = True
                    if textrect5.collidepoint(event.pos):
                        choosing = False
            display_surface.fill(color)
            display_surface.blit(black, (0, 0))
            display_surface.blit(text3, textrect3)
            display_surface.blit(text4, textrect4)
            display_surface.blit(text5, textrect5)
            display_surface.blit(text6, textrect6)
            if new is True:
                display_surface.blit(text7, textrect7)
            pygame.display.flip()
        if cervus1.alive is True:
            trees.clear()
            cervus1.x = 2
            game1.counter = 0
            game1.waiting = 1
            game()
        if cervus1.alive is False:
            game1.waiting = 2
        return
    start()
    game()
    pygame.quit()
    return


try:
    gui()
except Exception as err:
    print(str(err))
    time.sleep(100)
quit()
